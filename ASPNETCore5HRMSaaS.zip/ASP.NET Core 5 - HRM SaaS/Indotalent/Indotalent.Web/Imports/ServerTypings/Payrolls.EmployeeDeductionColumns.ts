﻿namespace Indotalent.Payrolls {
    export class EmployeeDeductionColumns {
        static columnsKey = 'Payrolls.EmployeeDeduction';
    }
}
