﻿namespace Indotalent.Performance {
    export class AppraisalColumns {
        static columnsKey = 'Performance.Appraisal';
    }
}
