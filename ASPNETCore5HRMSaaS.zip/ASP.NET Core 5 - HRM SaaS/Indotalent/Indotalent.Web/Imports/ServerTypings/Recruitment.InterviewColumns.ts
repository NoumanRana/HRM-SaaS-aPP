﻿namespace Indotalent.Recruitment {
    export class InterviewColumns {
        static columnsKey = 'Recruitment.Interview';
    }
}
