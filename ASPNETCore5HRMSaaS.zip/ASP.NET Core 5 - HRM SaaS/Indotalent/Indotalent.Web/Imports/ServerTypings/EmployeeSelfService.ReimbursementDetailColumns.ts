﻿namespace Indotalent.EmployeeSelfService {
    export class ReimbursementDetailColumns {
        static columnsKey = 'Operation.ReimbursementDetail';
    }
}
