﻿namespace Indotalent.Payrolls {
    export class EmployeeTopSkillColumns {
        static columnsKey = 'Payrolls.EmployeeTopSkill';
    }
}
