﻿namespace Indotalent.Payrolls {
    export class EmployeeExperienceColumns {
        static columnsKey = 'Payrolls.EmployeeExperience';
    }
}
