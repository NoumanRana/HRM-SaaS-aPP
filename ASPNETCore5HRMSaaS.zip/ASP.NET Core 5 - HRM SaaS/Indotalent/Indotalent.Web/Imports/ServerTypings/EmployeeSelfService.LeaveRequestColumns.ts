﻿namespace Indotalent.EmployeeSelfService {
    export class LeaveRequestColumns {
        static columnsKey = 'EmployeeSelfService.LeaveRequest';
    }
}
