﻿namespace Indotalent.EmployeeSelfService {
    export class TicketColumns {
        static columnsKey = 'EmployeeSelfService.Ticket';
    }
}
