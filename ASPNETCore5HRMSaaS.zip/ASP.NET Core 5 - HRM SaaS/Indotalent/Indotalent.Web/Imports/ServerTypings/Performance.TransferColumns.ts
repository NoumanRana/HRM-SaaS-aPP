﻿namespace Indotalent.Performance {
    export class TransferColumns {
        static columnsKey = 'Performance.Transfer';
    }
}
