﻿namespace Indotalent.Operation {
    export class MeetingParticipantColumns {
        static columnsKey = 'Operation.MeetingParticipant';
    }
}
