﻿namespace Indotalent.Payrolls {
    export class EmployeeKpiColumns {
        static columnsKey = 'Payrolls.EmployeeKpi';
    }
}
