﻿namespace Indotalent.Performance {
    export class PromotionReasonColumns {
        static columnsKey = 'Performance.PromotionReason';
    }
}
