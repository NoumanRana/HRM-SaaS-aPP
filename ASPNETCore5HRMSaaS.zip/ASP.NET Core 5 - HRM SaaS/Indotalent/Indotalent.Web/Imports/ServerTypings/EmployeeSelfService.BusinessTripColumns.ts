﻿namespace Indotalent.EmployeeSelfService {
    export class BusinessTripColumns {
        static columnsKey = 'EmployeeSelfService.BusinessTrip';
    }
}
