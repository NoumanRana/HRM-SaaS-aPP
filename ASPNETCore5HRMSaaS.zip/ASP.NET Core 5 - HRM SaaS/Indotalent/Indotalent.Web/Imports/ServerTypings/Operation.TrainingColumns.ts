﻿namespace Indotalent.Operation {
    export class TrainingColumns {
        static columnsKey = 'Operation.Training';
    }
}
