﻿namespace Indotalent.Organization {
    export class BranchColumns {
        static columnsKey = 'Organization.Branch';
    }
}
