﻿namespace Indotalent.EmployeeSelfService {
    export class PunchOutColumns {
        static columnsKey = 'EmployeeSelfService.PunchOut';
    }
}
