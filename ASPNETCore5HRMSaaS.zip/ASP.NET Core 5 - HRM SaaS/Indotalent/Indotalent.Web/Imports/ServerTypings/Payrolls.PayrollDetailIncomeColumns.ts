﻿namespace Indotalent.Payrolls {
    export class PayrollDetailIncomeColumns {
        static columnsKey = 'Payrolls.PayrollDetailIncome';
    }
}
