﻿namespace Indotalent.Operation {
    export class AssetColumns {
        static columnsKey = 'Operation.Asset';
    }
}
