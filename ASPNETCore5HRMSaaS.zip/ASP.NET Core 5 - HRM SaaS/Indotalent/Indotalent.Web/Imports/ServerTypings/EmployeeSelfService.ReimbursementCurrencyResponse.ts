﻿namespace Indotalent.EmployeeSelfService {
    export interface ReimbursementCurrencyResponse extends Serenity.ServiceResponse {
        Currency?: string;
    }
}
