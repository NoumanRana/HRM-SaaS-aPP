﻿namespace Indotalent.Recruitment {
    export class VacancyColumns {
        static columnsKey = 'Recruitment.Vacancy';
    }
}
