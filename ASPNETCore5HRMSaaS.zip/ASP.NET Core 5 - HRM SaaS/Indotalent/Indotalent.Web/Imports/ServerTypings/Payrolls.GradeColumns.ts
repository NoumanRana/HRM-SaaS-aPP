﻿namespace Indotalent.Payrolls {
    export class GradeColumns {
        static columnsKey = 'Payrolls.Grade';
    }
}
