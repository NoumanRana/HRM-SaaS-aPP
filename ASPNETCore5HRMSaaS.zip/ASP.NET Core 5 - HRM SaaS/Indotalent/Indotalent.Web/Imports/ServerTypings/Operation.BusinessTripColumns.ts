﻿namespace Indotalent.Operation {
    export class BusinessTripColumns {
        static columnsKey = 'Operation.BusinessTrip';
    }
}
