﻿namespace Indotalent.Operation {
    export class TerminationColumns {
        static columnsKey = 'Operation.Termination';
    }
}
