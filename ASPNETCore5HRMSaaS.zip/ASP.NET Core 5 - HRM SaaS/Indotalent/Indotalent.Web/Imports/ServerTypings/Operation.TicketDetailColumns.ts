﻿namespace Indotalent.Operation {
    export class TicketDetailColumns {
        static columnsKey = 'Operation.TicketDetail';
    }
}
