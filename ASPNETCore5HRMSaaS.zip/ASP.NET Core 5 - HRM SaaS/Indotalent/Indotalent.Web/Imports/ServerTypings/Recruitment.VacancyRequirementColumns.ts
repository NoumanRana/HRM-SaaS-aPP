﻿namespace Indotalent.Recruitment {
    export class VacancyRequirementColumns {
        static columnsKey = 'Recruitment.VacancyRequirement';
    }
}
