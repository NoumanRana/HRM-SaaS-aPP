﻿namespace Indotalent.Administration {
    export class UserColumns {
        static columnsKey = 'Administration.User';
    }
}
