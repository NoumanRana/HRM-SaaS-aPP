﻿namespace Indotalent.Operation {
    export class AwardColumns {
        static columnsKey = 'Operation.Award';
    }
}
