﻿namespace Indotalent.Operation {
    export class ReimbursementColumns {
        static columnsKey = 'Operation.Reimbursement';
    }
}
