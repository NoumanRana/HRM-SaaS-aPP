﻿namespace Indotalent.EmployeeSelfService {
    export class ComplaintColumns {
        static columnsKey = 'EmployeeSelfService.Complaint';
    }
}
