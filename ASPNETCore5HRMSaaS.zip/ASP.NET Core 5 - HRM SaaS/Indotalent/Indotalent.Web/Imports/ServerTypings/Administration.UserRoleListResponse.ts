﻿namespace Indotalent.Administration {
    export interface UserRoleListResponse extends Serenity.ListResponse<number> {
    }
}
