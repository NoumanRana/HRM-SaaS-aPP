﻿namespace Indotalent.Payrolls {
    export class EmployeeChildrenColumns {
        static columnsKey = 'Payrolls.EmployeeChildren';
    }
}
