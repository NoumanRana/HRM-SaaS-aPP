﻿namespace Indotalent.Recruitment {
    export class ApplicantTopSkillColumns {
        static columnsKey = 'Recruitment.ApplicantTopSkill';
    }
}
