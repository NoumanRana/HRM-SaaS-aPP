﻿namespace Indotalent.EmployeeSelfService {
    export interface AwardEmployeeIdResponse extends Serenity.ServiceResponse {
        EmployeeId?: number;
    }
}
