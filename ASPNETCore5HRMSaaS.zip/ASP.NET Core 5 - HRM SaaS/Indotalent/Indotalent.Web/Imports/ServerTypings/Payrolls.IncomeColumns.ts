﻿namespace Indotalent.Payrolls {
    export class IncomeColumns {
        static columnsKey = 'Payrolls.Income';
    }
}
