﻿namespace Indotalent.Operation {
    export class AnnouncementColumns {
        static columnsKey = 'Operation.Announcement';
    }
}
