﻿namespace Indotalent.EmployeeSelfService {
    export class MeetingParticipantColumns {
        static columnsKey = 'EmployeeSelfService.MeetingParticipant';
    }
}
