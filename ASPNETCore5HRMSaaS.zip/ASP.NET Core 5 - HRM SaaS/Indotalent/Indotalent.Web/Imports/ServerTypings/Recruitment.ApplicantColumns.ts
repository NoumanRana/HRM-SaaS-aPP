﻿namespace Indotalent.Recruitment {
    export class ApplicantColumns {
        static columnsKey = 'Recruitment.Applicant';
    }
}
