﻿namespace Indotalent.EmployeeSelfService {
    export interface TrainingEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
