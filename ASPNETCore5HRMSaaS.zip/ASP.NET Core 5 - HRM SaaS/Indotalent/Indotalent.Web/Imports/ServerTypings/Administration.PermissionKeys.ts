﻿namespace Indotalent.Administration {
    export namespace PermissionKeys {
        export const Security = "Administration:Security";
        export const Translation = "Administration:Translation";
        export const Tenant = "Administration:Tenant";
    }
}
