﻿namespace Indotalent.Payrolls {
    export interface GradeCurrencyResponse extends Serenity.ServiceResponse {
        Currency?: string;
    }
}
