﻿namespace Indotalent.EmployeeSelfService {
    export class AnnouncementColumns {
        static columnsKey = 'EmployeeSelfService.Announcement';
    }
}
