﻿namespace Indotalent.EmployeeSelfService {
    export interface BusinessTripEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
