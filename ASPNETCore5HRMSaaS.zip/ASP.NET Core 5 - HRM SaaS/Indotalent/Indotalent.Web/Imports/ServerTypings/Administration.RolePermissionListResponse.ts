﻿namespace Indotalent.Administration {
    export interface RolePermissionListResponse extends Serenity.ListResponse<string> {
    }
}
