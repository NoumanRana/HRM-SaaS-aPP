﻿namespace Indotalent.Payrolls {
    export class DeductionColumns {
        static columnsKey = 'Payrolls.Deduction';
    }
}
