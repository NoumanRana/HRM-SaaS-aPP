﻿namespace Indotalent.Performance {
    export class EvaluationColumns {
        static columnsKey = 'Performance.Evaluation';
    }
}
