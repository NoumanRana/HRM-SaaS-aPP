﻿namespace Indotalent.Leave {
    export class LeaveTypeColumns {
        static columnsKey = 'Leave.LeaveType';
    }
}
