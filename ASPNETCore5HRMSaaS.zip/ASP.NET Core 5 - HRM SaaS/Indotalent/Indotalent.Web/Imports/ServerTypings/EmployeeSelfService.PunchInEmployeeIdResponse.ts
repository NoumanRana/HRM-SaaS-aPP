﻿namespace Indotalent.EmployeeSelfService {
    export interface PunchInEmployeeIdResponse extends Serenity.ServiceResponse {
        EmployeeId?: number;
    }
}
