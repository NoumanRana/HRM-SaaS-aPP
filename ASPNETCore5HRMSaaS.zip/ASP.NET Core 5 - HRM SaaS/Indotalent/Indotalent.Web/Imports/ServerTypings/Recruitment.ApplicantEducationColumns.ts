﻿namespace Indotalent.Recruitment {
    export class ApplicantEducationColumns {
        static columnsKey = 'Recruitment.ApplicantEducation';
    }
}
