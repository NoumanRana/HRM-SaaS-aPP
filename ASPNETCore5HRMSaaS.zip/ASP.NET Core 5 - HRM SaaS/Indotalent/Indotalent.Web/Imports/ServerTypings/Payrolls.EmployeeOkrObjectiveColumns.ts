﻿namespace Indotalent.Payrolls {
    export class EmployeeOkrObjectiveColumns {
        static columnsKey = 'Payrolls.EmployeeOkrObjective';
    }
}
