﻿namespace Indotalent.Attendance {
    export class OvertimeColumns {
        static columnsKey = 'Attendance.Overtime';
    }
}
