﻿namespace Indotalent.EmployeeSelfService {
    export class MeetingColumns {
        static columnsKey = 'EmployeeSelfService.Meeting';
    }
}
