﻿namespace Indotalent.Performance {
    export class TransferReasonColumns {
        static columnsKey = 'Performance.TransferReason';
    }
}
