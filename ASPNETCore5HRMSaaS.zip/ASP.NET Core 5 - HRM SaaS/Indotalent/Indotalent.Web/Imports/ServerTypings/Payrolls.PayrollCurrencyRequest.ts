﻿namespace Indotalent.Payrolls {
    export interface PayrollCurrencyRequest extends Serenity.ServiceRequest {
    }
}
