﻿namespace Indotalent.EmployeeSelfService {
    export interface LeaveRequestEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
