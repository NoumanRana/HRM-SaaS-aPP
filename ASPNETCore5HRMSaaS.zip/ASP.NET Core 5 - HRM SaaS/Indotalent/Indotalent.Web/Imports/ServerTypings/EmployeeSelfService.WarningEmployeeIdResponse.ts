﻿namespace Indotalent.EmployeeSelfService {
    export interface WarningEmployeeIdResponse extends Serenity.ServiceResponse {
        EmployeeId?: number;
    }
}
