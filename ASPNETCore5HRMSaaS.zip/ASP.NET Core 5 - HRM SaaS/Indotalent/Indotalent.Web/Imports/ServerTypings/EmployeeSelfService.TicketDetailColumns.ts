﻿namespace Indotalent.EmployeeSelfService {
    export class TicketDetailColumns {
        static columnsKey = 'EmployeeSelfService.TicketDetail';
    }
}
