﻿namespace Indotalent.Leave {
    export class LeaveRequestColumns {
        static columnsKey = 'Leave.LeaveRequest';
    }
}
