﻿namespace Indotalent.Attendance {
    export interface PunchInEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
