﻿namespace Indotalent.Payrolls {
    export class PayrollColumns {
        static columnsKey = 'Payrolls.Payroll';
    }
}
