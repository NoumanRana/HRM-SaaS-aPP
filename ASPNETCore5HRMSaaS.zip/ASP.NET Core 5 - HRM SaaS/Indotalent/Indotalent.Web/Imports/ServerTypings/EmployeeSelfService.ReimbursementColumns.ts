﻿namespace Indotalent.EmployeeSelfService {
    export class ReimbursementColumns {
        static columnsKey = 'Operation.Reimbursement';
    }
}
