﻿namespace Indotalent.Leave {
    export class LeaveEmergencyContactColumns {
        static columnsKey = 'Leave.LeaveEmergencyContact';
    }
}
