﻿namespace Indotalent.Organization {
    export class DesignationColumns {
        static columnsKey = 'Organization.Designation';
    }
}
