﻿namespace Indotalent.EmployeeSelfService {
    export class WarningColumns {
        static columnsKey = 'EmployeeSelfService.Warning';
    }
}
