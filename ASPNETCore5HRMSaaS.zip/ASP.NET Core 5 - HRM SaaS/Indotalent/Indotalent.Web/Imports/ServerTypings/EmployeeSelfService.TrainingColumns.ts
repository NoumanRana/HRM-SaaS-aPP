﻿namespace Indotalent.EmployeeSelfService {
    export class TrainingColumns {
        static columnsKey = 'EmployeeSelfService.Training';
    }
}
