﻿namespace Indotalent.Leave {
    export class LeaveDelegatedTaskColumns {
        static columnsKey = 'Leave.LeaveDelegatedTask';
    }
}
