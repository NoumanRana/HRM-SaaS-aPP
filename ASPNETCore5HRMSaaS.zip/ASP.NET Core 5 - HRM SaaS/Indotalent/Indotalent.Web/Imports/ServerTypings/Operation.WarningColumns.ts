﻿namespace Indotalent.Operation {
    export class WarningColumns {
        static columnsKey = 'Operation.Warning';
    }
}
