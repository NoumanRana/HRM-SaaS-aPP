﻿namespace Indotalent.Organization {
    export class DepartmentColumns {
        static columnsKey = 'Organization.Department';
    }
}
