﻿namespace Indotalent.EmployeeSelfService {
    export interface LeaveRequestEmployeeIdResponse extends Serenity.ServiceResponse {
        EmployeeId?: number;
    }
}
