﻿namespace Indotalent.Payrolls {
    export class PayrollDetailColumns {
        static columnsKey = 'Payrolls.PayrollDetail';
    }
}
