﻿namespace Indotalent.Payrolls {
    export class EmployeeOkrResultColumns {
        static columnsKey = 'Payrolls.EmployeeOkrResult';
    }
}
