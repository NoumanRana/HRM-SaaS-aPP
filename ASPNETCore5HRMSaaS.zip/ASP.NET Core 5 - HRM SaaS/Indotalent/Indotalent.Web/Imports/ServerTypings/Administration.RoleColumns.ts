﻿namespace Indotalent.Administration {
    export class RoleColumns {
        static columnsKey = 'Administration.Role';
    }
}
