﻿namespace Indotalent.Attendance {
    export interface OvertimeEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
