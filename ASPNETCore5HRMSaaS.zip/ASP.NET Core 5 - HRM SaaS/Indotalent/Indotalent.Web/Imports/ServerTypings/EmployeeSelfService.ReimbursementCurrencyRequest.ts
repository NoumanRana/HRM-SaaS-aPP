﻿namespace Indotalent.EmployeeSelfService {
    export interface ReimbursementCurrencyRequest extends Serenity.ServiceRequest {
    }
}
