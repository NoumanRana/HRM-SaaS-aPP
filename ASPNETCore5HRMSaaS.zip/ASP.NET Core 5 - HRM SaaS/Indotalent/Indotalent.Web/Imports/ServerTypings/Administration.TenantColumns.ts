﻿namespace Indotalent.Administration {
    export class TenantColumns {
        static columnsKey = 'Administration.Tenant';
    }
}
