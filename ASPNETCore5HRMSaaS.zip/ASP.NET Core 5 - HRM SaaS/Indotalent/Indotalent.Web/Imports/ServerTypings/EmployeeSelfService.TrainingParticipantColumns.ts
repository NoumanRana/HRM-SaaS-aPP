﻿namespace Indotalent.EmployeeSelfService {
    export class TrainingParticipantColumns {
        static columnsKey = 'EmployeeSelfService.TrainingParticipant';
    }
}
