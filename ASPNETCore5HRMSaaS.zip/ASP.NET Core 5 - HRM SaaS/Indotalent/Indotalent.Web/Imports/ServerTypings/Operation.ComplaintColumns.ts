﻿namespace Indotalent.Operation {
    export class ComplaintColumns {
        static columnsKey = 'Operation.Complaint';
    }
}
