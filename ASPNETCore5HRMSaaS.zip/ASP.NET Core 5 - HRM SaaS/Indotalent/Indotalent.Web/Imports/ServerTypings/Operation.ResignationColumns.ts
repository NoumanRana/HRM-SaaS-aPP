﻿namespace Indotalent.Operation {
    export class ResignationColumns {
        static columnsKey = 'Operation.Resignation';
    }
}
