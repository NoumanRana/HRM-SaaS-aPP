﻿namespace Indotalent.Payrolls {
    export class EmployeeColumns {
        static columnsKey = 'Payrolls.Employee';
    }
}
