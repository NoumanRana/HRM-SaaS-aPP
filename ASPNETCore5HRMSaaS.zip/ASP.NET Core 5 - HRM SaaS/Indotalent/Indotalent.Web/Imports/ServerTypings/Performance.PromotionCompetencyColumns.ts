﻿namespace Indotalent.Performance {
    export class PromotionCompetencyColumns {
        static columnsKey = 'Performance.PromotionCompetency';
    }
}
