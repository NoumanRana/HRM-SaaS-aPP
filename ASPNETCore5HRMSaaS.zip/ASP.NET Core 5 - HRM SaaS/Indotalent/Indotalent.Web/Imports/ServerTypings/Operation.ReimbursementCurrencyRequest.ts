﻿namespace Indotalent.Operation {
    export interface ReimbursementCurrencyRequest extends Serenity.ServiceRequest {
    }
}
