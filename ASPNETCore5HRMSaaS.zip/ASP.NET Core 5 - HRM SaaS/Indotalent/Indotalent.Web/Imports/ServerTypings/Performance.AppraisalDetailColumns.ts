﻿namespace Indotalent.Performance {
    export class AppraisalDetailColumns {
        static columnsKey = 'Performance.AppraisalDetail';
    }
}
