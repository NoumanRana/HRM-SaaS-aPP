﻿namespace Indotalent.Operation {
    export class ReimbursementDetailColumns {
        static columnsKey = 'Operation.ReimbursementDetail';
    }
}
