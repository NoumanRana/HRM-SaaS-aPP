﻿namespace Indotalent.EmployeeSelfService {
    export class PunchInColumns {
        static columnsKey = 'EmployeeSelfService.PunchIn';
    }
}
