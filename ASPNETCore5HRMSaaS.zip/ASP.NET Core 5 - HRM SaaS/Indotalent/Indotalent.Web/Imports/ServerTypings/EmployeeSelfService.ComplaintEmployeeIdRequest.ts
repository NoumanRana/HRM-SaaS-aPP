﻿namespace Indotalent.EmployeeSelfService {
    export interface ComplaintEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
