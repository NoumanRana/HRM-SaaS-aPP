﻿namespace Indotalent.Payrolls {
    export class EmployeeParentColumns {
        static columnsKey = 'Payrolls.EmployeeParent';
    }
}
