﻿namespace Indotalent.Operation {
    export class BusinessTripParticipantColumns {
        static columnsKey = 'Operation.BusinessTripParticipant';
    }
}
