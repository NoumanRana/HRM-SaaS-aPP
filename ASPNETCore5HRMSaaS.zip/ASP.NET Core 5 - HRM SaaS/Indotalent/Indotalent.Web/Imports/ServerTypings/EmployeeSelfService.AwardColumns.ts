﻿namespace Indotalent.EmployeeSelfService {
    export class AwardColumns {
        static columnsKey = 'EmployeeSelfService.Award';
    }
}
