﻿namespace Indotalent.EmployeeSelfService {
    export class LeaveDelegatedTaskColumns {
        static columnsKey = 'EmployeeSelfService.LeaveDelegatedTask';
    }
}
