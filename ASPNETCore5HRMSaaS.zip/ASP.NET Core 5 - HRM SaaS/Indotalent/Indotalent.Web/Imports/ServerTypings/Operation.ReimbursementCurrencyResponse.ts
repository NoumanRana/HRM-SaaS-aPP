﻿namespace Indotalent.Operation {
    export interface ReimbursementCurrencyResponse extends Serenity.ServiceResponse {
        Currency?: string;
    }
}
