﻿namespace Indotalent.EmployeeSelfService {
    export interface AwardEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
