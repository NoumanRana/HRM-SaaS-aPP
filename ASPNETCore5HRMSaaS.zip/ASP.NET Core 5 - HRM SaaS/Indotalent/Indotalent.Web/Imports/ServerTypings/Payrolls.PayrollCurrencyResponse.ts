﻿namespace Indotalent.Payrolls {
    export interface PayrollCurrencyResponse extends Serenity.ServiceResponse {
        Currency?: string;
    }
}
