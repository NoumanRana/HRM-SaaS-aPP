﻿namespace Indotalent.Payrolls {
    export interface GradeCurrencyRequest extends Serenity.ServiceRequest {
    }
}
