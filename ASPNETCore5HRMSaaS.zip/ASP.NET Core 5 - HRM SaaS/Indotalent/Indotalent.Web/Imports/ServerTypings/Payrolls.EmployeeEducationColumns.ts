﻿namespace Indotalent.Payrolls {
    export class EmployeeEducationColumns {
        static columnsKey = 'Payrolls.EmployeeEducation';
    }
}
