﻿namespace Indotalent.Operation {
    export class TrainingParticipantColumns {
        static columnsKey = 'Operation.TrainingParticipant';
    }
}
