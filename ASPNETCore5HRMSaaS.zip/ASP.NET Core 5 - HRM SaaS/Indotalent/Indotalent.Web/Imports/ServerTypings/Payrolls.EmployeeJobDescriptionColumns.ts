﻿namespace Indotalent.Payrolls {
    export class EmployeeJobDescriptionColumns {
        static columnsKey = 'Payrolls.EmployeeJobDescription';
    }
}
