﻿namespace Indotalent.Operation {
    export class HolidayColumns {
        static columnsKey = 'Operation.Holiday';
    }
}
