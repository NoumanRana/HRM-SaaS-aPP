﻿namespace Indotalent.EmployeeSelfService {
    export interface PunchInEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
