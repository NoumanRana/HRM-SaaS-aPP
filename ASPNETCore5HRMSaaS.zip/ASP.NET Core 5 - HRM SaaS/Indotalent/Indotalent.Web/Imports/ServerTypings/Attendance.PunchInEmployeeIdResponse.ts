﻿namespace Indotalent.Attendance {
    export interface PunchInEmployeeIdResponse extends Serenity.ServiceResponse {
        EmployeeId?: number;
    }
}
