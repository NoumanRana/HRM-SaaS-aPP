﻿namespace Indotalent.Payrolls {
    export class PayrollDetailDeductionColumns {
        static columnsKey = 'Payrolls.PayrollDetailDeduction';
    }
}
