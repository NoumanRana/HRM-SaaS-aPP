﻿namespace Indotalent.Operation {
    export class AssetHandOverColumns {
        static columnsKey = 'Operation.AssetHandOver';
    }
}
