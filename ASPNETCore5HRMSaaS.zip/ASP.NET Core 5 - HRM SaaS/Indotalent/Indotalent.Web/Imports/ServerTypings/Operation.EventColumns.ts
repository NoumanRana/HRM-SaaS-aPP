﻿namespace Indotalent.Operation {
    export class EventColumns {
        static columnsKey = 'Operation.Event';
    }
}
