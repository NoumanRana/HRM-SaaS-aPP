﻿namespace Indotalent.Payrolls {
    export class EmployeeIncomeColumns {
        static columnsKey = 'Payrolls.EmployeeIncome';
    }
}
