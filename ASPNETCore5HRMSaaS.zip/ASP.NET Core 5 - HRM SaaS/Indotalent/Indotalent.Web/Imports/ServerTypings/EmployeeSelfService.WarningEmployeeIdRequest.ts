﻿namespace Indotalent.EmployeeSelfService {
    export interface WarningEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
