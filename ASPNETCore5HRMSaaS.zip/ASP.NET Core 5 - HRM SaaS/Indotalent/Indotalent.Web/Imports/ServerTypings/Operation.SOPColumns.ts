﻿namespace Indotalent.Operation {
    export class SOPColumns {
        static columnsKey = 'Operation.SOP';
    }
}
