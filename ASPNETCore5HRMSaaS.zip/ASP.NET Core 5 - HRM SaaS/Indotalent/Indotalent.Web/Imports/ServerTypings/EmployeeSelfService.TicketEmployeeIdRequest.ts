﻿namespace Indotalent.EmployeeSelfService {
    export interface TicketEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
