﻿namespace Indotalent.Attendance {
    export class PunchInColumns {
        static columnsKey = 'Attendance.PunchIn';
    }
}
