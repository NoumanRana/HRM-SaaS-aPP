﻿namespace Indotalent.EmployeeSelfService {
    export interface ReimbursementEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
