﻿namespace Indotalent.EmployeeSelfService {
    export class OvertimeColumns {
        static columnsKey = 'EmployeeSelfService.Overtime';
    }
}
