﻿namespace Indotalent.EmployeeSelfService {
    export class TimesheetColumns {
        static columnsKey = 'EmployeeSelfService.Timesheet';
    }
}
