﻿namespace Indotalent.Performance {
    export class TransferCompetencyColumns {
        static columnsKey = 'Performance.TransferCompetency';
    }
}
