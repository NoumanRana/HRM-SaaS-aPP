﻿namespace Indotalent.Recruitment {
    export class VacancyBenefitColumns {
        static columnsKey = 'Recruitment.VacancyBenefit';
    }
}
