﻿namespace Indotalent.EmployeeSelfService {
    export interface OvertimeEmployeeIdResponse extends Serenity.ServiceResponse {
        EmployeeId?: number;
    }
}
