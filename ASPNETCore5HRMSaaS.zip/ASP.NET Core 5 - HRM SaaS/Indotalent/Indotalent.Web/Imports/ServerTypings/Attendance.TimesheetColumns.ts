﻿namespace Indotalent.Attendance {
    export class TimesheetColumns {
        static columnsKey = 'Attendance.Timesheet';
    }
}
