﻿namespace Indotalent.EmployeeSelfService {
    export class LeaveEmergencyContactColumns {
        static columnsKey = 'EmployeeSelfService.LeaveEmergencyContact';
    }
}
