﻿namespace Indotalent.Administration {
    export class LanguageColumns {
        static columnsKey = 'Administration.Language';
    }
}
