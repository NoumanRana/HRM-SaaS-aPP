﻿namespace Indotalent.Performance {
    export class PromotionColumns {
        static columnsKey = 'Performance.Promotion';
    }
}
