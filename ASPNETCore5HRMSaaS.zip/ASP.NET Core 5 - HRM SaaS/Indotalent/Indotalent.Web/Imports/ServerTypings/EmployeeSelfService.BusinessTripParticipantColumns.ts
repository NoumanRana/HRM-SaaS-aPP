﻿namespace Indotalent.EmployeeSelfService {
    export class BusinessTripParticipantColumns {
        static columnsKey = 'EmployeeSelfService.BusinessTripParticipant';
    }
}
