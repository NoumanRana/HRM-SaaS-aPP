﻿namespace Indotalent.Attendance {
    export interface OvertimeEmployeeIdResponse extends Serenity.ServiceResponse {
        EmployeeId?: number;
    }
}
