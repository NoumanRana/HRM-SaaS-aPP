﻿namespace Indotalent.Operation {
    export class TicketColumns {
        static columnsKey = 'Operation.Ticket';
    }
}
