﻿namespace Indotalent.Recruitment {
    export class InterviewResultColumns {
        static columnsKey = 'Recruitment.InterviewResult';
    }
}
