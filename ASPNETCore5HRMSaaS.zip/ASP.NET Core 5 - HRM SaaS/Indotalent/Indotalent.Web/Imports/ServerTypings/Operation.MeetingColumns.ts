﻿namespace Indotalent.Operation {
    export class MeetingColumns {
        static columnsKey = 'Operation.Meeting';
    }
}
