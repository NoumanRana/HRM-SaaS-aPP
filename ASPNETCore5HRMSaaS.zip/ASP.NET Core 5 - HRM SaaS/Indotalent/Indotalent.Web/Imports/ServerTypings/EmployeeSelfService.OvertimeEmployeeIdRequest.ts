﻿namespace Indotalent.EmployeeSelfService {
    export interface OvertimeEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
