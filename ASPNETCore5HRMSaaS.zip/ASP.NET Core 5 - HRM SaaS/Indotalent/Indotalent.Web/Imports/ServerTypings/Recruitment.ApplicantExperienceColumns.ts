﻿namespace Indotalent.Recruitment {
    export class ApplicantExperienceColumns {
        static columnsKey = 'Recruitment.ApplicantExperience';
    }
}
