﻿namespace Indotalent.EmployeeSelfService {
    export interface MeetingEmployeeIdRequest extends Serenity.ServiceRequest {
    }
}
