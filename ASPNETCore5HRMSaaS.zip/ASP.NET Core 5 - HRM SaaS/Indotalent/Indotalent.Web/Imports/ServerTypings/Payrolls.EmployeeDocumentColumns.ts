﻿namespace Indotalent.Payrolls {
    export class EmployeeDocumentColumns {
        static columnsKey = 'Payrolls.EmployeeDocument';
    }
}
