﻿namespace Indotalent.Attendance {
    export class PunchOutColumns {
        static columnsKey = 'Attendance.PunchOut';
    }
}
